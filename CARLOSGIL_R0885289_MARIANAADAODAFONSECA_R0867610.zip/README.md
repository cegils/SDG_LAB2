Type here details of the model.
References
CHOLLET, Francois. Deep learning with Python. Simon and Schuster, 2021.

Keras Library Docs
https://keras.io/api/layers/
